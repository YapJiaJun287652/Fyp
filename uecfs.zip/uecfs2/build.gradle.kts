buildscript {
    repositories {
        google() // Google's Maven repository
        // Other repositories if needed
    }
    dependencies {
        classpath("com.android.tools.build:gradle:8.2.2") // Android Gradle Plugin dependency
        // Other dependencies if needed
    }
}

repositories {
    google() // Google's Maven repository
    mavenCentral() // Maven Central repository
}

