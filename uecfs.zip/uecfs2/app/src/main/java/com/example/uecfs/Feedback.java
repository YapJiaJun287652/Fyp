package com.example.uecfs;
public class Feedback {
    private String locationDescription;
    private int cleanlinessRating;
    private String status;

    public Feedback(String locationDescription, int cleanlinessRating) {
        this.locationDescription = locationDescription;
        this.cleanlinessRating = cleanlinessRating;
        this.status = status;
    }

    // Getters and setters
    public String getLocationDescription() {
        return locationDescription;
    }

    public void setLocationDescription(String locationDescription) {
        this.locationDescription = locationDescription;
    }

    public int getCleanlinessRating() {
        return cleanlinessRating;
    }

    public void setCleanlinessRating(int cleanlinessRating) {
        this.cleanlinessRating = cleanlinessRating;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

