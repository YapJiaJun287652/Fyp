package com.example.uecfs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class LogOutActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_out);

        mAuth = FirebaseAuth.getInstance();
    }

    public void performLogout(View view) {
        mAuth.signOut(); // Logout from Firebase

        // After logging out, you can redirect the user to the login screen or any other screen
        Intent intent = new Intent(LogOutActivity.this, MainActivity.class);
        startActivity(intent);

        finish(); // Close the current activity
    }
}

