package com.example.uecfs;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference().child("users");
    }
    public void registerUser(View view) {
        EditText nameEditText = findViewById(R.id.editTextText2);
        EditText emailEditText = findViewById(R.id.editTextText3);  // Changed from usernameEditText
        EditText matricNoEditText = findViewById(R.id.editTextNumber);
        EditText passwordEditText = findViewById(R.id.editTextTextPassword4);

        String name = nameEditText.getText().toString();
        String email = emailEditText.getText().toString();  // Changed from username
        String matricNo = matricNoEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Determine the selected gender
        String gender = "";
        Button maleButton = findViewById(R.id.button4);
        Button femaleButton = findViewById(R.id.button5);

        if (maleButton.isPressed()) {
            gender = "Male";
        } else if (femaleButton.isPressed()) {
            gender = "Female";
        }

        // Determine the selected role
        String role = "";
        Button studentButton = findViewById(R.id.button8);
        Button staffButton = findViewById(R.id.button6);

        if (studentButton.isPressed()) {
            role = "Student";
        } else if (staffButton.isPressed()) {
            role = "Staff";
        }

        // Register user with Firebase Authentication
        final String finalGender = gender;  // Declare it as final
        final String finalRole = role;  // Declare it as final

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // User registered successfully
                            // Now, add additional user information to the Realtime Database
                            String userId = mAuth.getCurrentUser().getUid();
                            DatabaseReference currentUserDb = mDatabase.child(userId);

                            currentUserDb.child("name").setValue(name);
                            currentUserDb.child("matricNo").setValue(matricNo);
                            currentUserDb.child("gender").setValue(finalGender);
                            currentUserDb.child("role").setValue(finalRole);

                            // Inform the user about successful registration
                            Toast.makeText(RegisterActivity.this, "Registration successful!", Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            // If registration fails, display a message to the user.
                            Toast.makeText(RegisterActivity.this, "Registration failed. " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}


