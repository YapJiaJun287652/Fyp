package com.example.uecfs;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class GiveFeedbackActivity extends AppCompatActivity {

    EditText etLocationDescription;
    ImageButton btnCamera;
    ImageButton btnLocation;
    ImageButton btnInProgress;
    ImageButton btnResolved;
    RadioGroup radioGroup;
    Button btnSubmit;

    FirebaseDatabase database;
    DatabaseReference reference;

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_give_feedback);

        etLocationDescription = findViewById(R.id.etLocationDescription);
        btnCamera = findViewById(R.id.imageButton12);
        btnLocation = findViewById(R.id.imageButton14);
        btnInProgress = findViewById(R.id.imageButton16);
        btnResolved = findViewById(R.id.imageButton17);
        radioGroup = findViewById(R.id.radioGroup);
        btnSubmit = findViewById(R.id.button13);

        // Initialize Firebase
        database = FirebaseDatabase.getInstance();
        reference = database.getReference("feedback");

        // Request location permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        }

        btnLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get user's current location
                fetchCurrentLocation();
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String locationDescription = etLocationDescription.getText().toString();
                int cleanlinessRating = getCleanlinessRating();

                if (cleanlinessRating == 0) {
                    Toast.makeText(GiveFeedbackActivity.this, "Please select a cleanliness rating!", Toast.LENGTH_SHORT).show();
                } else {
                    // Create a new Feedback object
                    Feedback feedback = new Feedback(locationDescription, cleanlinessRating);

                    // Push the feedback to Firebase
                    reference.push().setValue(feedback)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Toast.makeText(GiveFeedbackActivity.this, "Feedback submitted successfully!", Toast.LENGTH_SHORT).show();
                                    openHomePageActivity();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(GiveFeedbackActivity.this, "Failed to submit feedback: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                }
            }
        });
    }

    private void fetchCurrentLocation() {
        // Check if permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            // Create a FusedLocationProviderClient
            FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

            // Get last known location
            fusedLocationClient.getLastLocation()
                    .addOnSuccessListener(new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            if (location != null) {
                                // Save the coordinates to the database
                                reference.child("coordinates").setValue(location.getLatitude() + ", " + location.getLongitude());
                                Toast.makeText(GiveFeedbackActivity.this, "Location retrieved successfully!", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(GiveFeedbackActivity.this, "Location not available", Toast.LENGTH_SHORT).show();
                            }
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(GiveFeedbackActivity.this, "Failed to get location: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        } else {
            // If permission is not granted, request it
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    private int getCleanlinessRating() {
        int checkedRadioButtonId = radioGroup.getCheckedRadioButtonId();

        if (checkedRadioButtonId == R.id.radioOption1) {
            return 1;
        } else if (checkedRadioButtonId == R.id.radioOption2) {
            return 2;
        } else if (checkedRadioButtonId == R.id.radioOption3) {
            return 3;
        } else if (checkedRadioButtonId == R.id.radioOption4) {
            return 4;
        } else if (checkedRadioButtonId == R.id.radioOption5) {
            return 5;
        } else {
            return 0;
        }
    }

    private void openHomePageActivity() {
        Intent intent = new Intent(GiveFeedbackActivity.this, HomePageActivity.class);
        startActivity(intent);
    }
}

