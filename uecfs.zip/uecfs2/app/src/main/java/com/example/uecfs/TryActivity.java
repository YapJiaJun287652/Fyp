package com.example.uecfs;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class TryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_try);

        // Get the ImageButtons
        ImageButton cameraButton = findViewById(R.id.imageButton12);
        ImageButton gpsButton = findViewById(R.id.imageButton14);
        ImageButton inProgressButton = findViewById(R.id.imageButton16);
        ImageButton resolvedButton = findViewById(R.id.imageButton17);

        // Set onTouchListener for making buttons darker on press
        cameraButton.setOnTouchListener(darkenOnTouch);
        gpsButton.setOnTouchListener(darkenOnTouch);
        inProgressButton.setOnTouchListener(darkenOnTouch);
        resolvedButton.setOnTouchListener(darkenOnTouch);

        // Set onClickListener for buttons (you can add your logic here)
        cameraButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add your logic for camera button click
                Toast.makeText(TryActivity.this, "Camera Button Clicked", Toast.LENGTH_SHORT).show();
            }
        });

        gpsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add your logic for GPS button click
                Toast.makeText(TryActivity.this, "GPS Button Clicked", Toast.LENGTH_SHORT).show();
            }
        });

        inProgressButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add your logic for in-progress button click
                Toast.makeText(TryActivity.this, "In Progress Button Clicked", Toast.LENGTH_SHORT).show();
            }
        });

        resolvedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add your logic for resolved button click
                Toast.makeText(TryActivity.this, "Resolved Button Clicked", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // OnTouchListener to make ImageButton darker on press
    private final View.OnTouchListener darkenOnTouch = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    // Darken the ImageButton on press
                    v.getBackground().setAlpha(150);
                    break;

                case MotionEvent.ACTION_UP:
                    // Restore the original state on release
                    v.getBackground().setAlpha(255);
                    break;
            }
            return false;
        }
    };

    public void openHomePageActivity(View view) {
        Intent intent = new Intent(TryActivity.this, HomePageActivity.class);
        startActivity(intent);
    }
}
